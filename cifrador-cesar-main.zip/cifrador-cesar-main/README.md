# cifrador-cesar
Cifrado César hecho con JS

<img src="https://i.ibb.co/5FdyLVM/Screen-Shot-2021-02-25-at-00-15-17.png" alt="cesar" width="400"/>

**Calculadora desarrollada en este tutorial: https://youtu.be/7A4pdwpT10Q** 

Tecnologías:
- HTML
- Css
- JavaScript
